package com.PlacementManagement.StudentSetvice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentSetviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
